import express from 'express';
import db from '../db/database.js';
const router = express.Router();

router.get('/salones', async (req, res) => {
  const salones = await db.all('SELECT * FROM salones');
  res.json(salones);
});

router.get('/eventos/:id_salon', async (req, res) => {
  const eventos = await db.all('SELECT * FROM eventos WHERE id_salon = ?', [req.params.id_salon]);
  res.json(eventos);
});

router.post('/eventos', async (req, res) => {
  const { id_salon, titulo, encargado, fecha_inicio, fecha_fin, repeticion, cupo } = req.body;
  await db.run(
    `INSERT INTO eventos (id_salon, titulo, encargado, fecha_inicio, fecha_fin, repeticion, cupo)
     VALUES (?, ?, ?, ?, ?, ?, ?)`,
    [id_salon, titulo, encargado, fecha_inicio, fecha_fin, repeticion, cupo]
  );
  res.status(201).json({ mensaje: 'Evento creado' });
});

router.post('/disponibilidad', async (req, res) => {
  const { fecha_inicio, fecha_fin, cupo } = req.body;
  const salonesDisponibles = await db.all(`
    SELECT * FROM salones WHERE capacidad >= ?
    AND id NOT IN (
      SELECT id_salon FROM eventos
      WHERE (datetime(fecha_inicio) < datetime(?)) AND (datetime(fecha_fin) > datetime(?))
    )
  `, [cupo, fecha_fin, fecha_inicio]);

  res.json(salonesDisponibles);
});

router.post('/salones', async (req, res) => {
  const { nombre, capacidad, multimedia, novedades } = req.body;
  await db.run(
    `INSERT INTO salones (nombre, capacidad, multimedia, novedades)
     VALUES (?, ?, ?, ?)`,
    [nombre, capacidad, multimedia || '', novedades || '']
  );
  res.status(201).json({ mensaje: 'Salón creado' });
});


export default router;