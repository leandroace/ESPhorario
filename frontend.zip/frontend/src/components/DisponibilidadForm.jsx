import { useState } from 'react';
import axios from 'axios';

function DisponibilidadForm() {
  const [form, setForm] = useState({
    fecha_inicio: '',
    fecha_fin: '',
    cupo: ''
  });
  const [resultado, setResultado] = useState([]);
  const [mensaje, setMensaje] = useState('');

  const handleChange = e => {
    const { name, value } = e.target;
    setForm(prev => ({ ...prev, [name]: value }));
  };

  const handleSubmit = e => {
    e.preventDefault();

    // Validar campos
    if (!form.fecha_inicio || !form.fecha_fin || !form.cupo) {
      setMensaje('Por favor llena todos los campos');
      setResultado([]);
      return;
    }

    axios.post('http://localhost:3001/api/disponibilidad', form)
      .then(res => {
        if (res.data.length > 0) {
          setResultado(res.data);
          setMensaje(`Salones disponibles: ${res.data.length}`);
        } else {
          setResultado([]);
          setMensaje('No hay salones disponibles para los criterios indicados.');
        }
      })
      .catch(() => {
        setMensaje('Error al consultar disponibilidad');
        setResultado([]);
      });
  };

  return (
    <div style={{ marginTop: '1rem', marginBottom: '1rem' }}>
      <h4>Consultar disponibilidad de salones</h4>
      <form onSubmit={handleSubmit}>
        <label>Inicio: <input type="datetime-local" name="fecha_inicio" onChange={handleChange} /></label>
        <label> Fin: <input type="datetime-local" name="fecha_fin" onChange={handleChange} /></label>
        <label> Cupo: <input type="number" name="cupo" onChange={handleChange} /></label>
        <button type="submit">Consultar</button>
      </form>
      <p><strong>{mensaje}</strong></p>
      <ul>
        {resultado.map(s => <li key={s.id}>{s.nombre} – capacidad: {s.capacidad}</li>)}
      </ul>
    </div>
  );
}

export default DisponibilidadForm;
