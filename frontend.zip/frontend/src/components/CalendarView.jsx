import FullCalendar from '@fullcalendar/react';
import dayGridPlugin from '@fullcalendar/daygrid';
import timeGridPlugin from '@fullcalendar/timegrid';
import interactionPlugin from '@fullcalendar/interaction';
import { useEffect, useState } from 'react';
import axios from 'axios';

function CalendarView({ salon }) {
  const [eventos, setEventos] = useState([]);

  useEffect(() => {
    axios.get(`http://localhost:3001/api/eventos/${salon.id}`).then(res => {
      setEventos(res.data.map(e => ({
        title: e.titulo,
        start: e.fecha_inicio,
        end: e.fecha_fin
      })));
    });
  }, [salon]);

  return (
    <FullCalendar
      plugins={[dayGridPlugin, timeGridPlugin, interactionPlugin]}
      initialView="timeGridWeek"
      events={eventos}
      height="auto"
      slotMinTime="07:00:00"   // ⏰ Hora mínima visible
      slotMaxTime="21:00:00"   // ⏰ Hora máxima visible
    />
  );
}

export default CalendarView;