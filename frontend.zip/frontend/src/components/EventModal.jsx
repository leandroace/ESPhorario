import Modal from 'react-modal';
import { useState } from 'react';
import axios from 'axios';

function EventModal({ closeModal, salones }) {
  const [form, setForm] = useState({
    id_salon: salones[0]?.id || 1,
    titulo: '',
    encargado: '',
    fecha_inicio: '',
    fecha_fin: '',
    repeticion: 'no',
    cupo: 1
  });

  const handleChange = e => {
    const { name, value } = e.target;
    setForm(prev => ({ ...prev, [name]: value }));
  };

  const handleSubmit = e => {
    e.preventDefault();
    axios.post('http://localhost:3001/api/eventos', form).then(() => {
      alert('Evento creado');
      closeModal();
    });
  };

  return (
    <Modal isOpen={true} onRequestClose={closeModal} ariaHideApp={false}>
      <h3>Crear Evento</h3>
      <form onSubmit={handleSubmit}>
        <label>Salón:
          <select name="id_salon" value={form.id_salon} onChange={handleChange}>
            {salones.map(s => <option key={s.id} value={s.id}>{s.nombre}</option>)}
          </select>
        </label><br />
        <label>Título: <input name="titulo" onChange={handleChange} /></label><br />
        <label>Encargado: <input name="encargado" onChange={handleChange} /></label><br />
        <label>Inicio: <input type="datetime-local" name="fecha_inicio" onChange={handleChange} /></label><br />
        <label>Fin: <input type="datetime-local" name="fecha_fin" onChange={handleChange} /></label><br />
        <label>Repetición:
          <select name="repeticion" onChange={handleChange}>
            <option value="no">No se repite</option>
            <option value="diaria">Cada día</option>
            <option value="semanal">Cada semana</option>
          </select>
        </label><br />
        <label>Cupo: <input type="number" name="cupo" onChange={handleChange} /></label><br />
        <button type="submit">Guardar</button>
      </form>
    </Modal>
  );
}

export default EventModal;