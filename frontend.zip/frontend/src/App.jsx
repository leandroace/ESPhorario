import { useEffect, useState } from 'react';
import { Tab, Tabs, TabList, TabPanel } from 'react-tabs';
import 'react-tabs/style/react-tabs.css';
import CalendarView from './components/CalendarView';
import EventModal from './components/EventModal';
import DisponibilidadForm from './components/DisponibilidadForm';
import SalonForm from './components/SalonForm';
import axios from 'axios';

function App() {
  const [salones, setSalones] = useState([]);
  const [modalOpen, setModalOpen] = useState(false);
  const [selectedSalon, setSelectedSalon] = useState(0);
  
  useEffect(() => {
    axios.get('http://localhost:3001/api/salones').then(res => setSalones(res.data));
  }, []);

  return (
    <div className="App" style={{ padding: '1rem' }}>
      <h2>Gestión de Horarios</h2>
      <button onClick={() => setModalOpen(true)}>Crear Evento</button>
      <DisponibilidadForm />
      <SalonForm onSalonCreado={() => {
        axios.get('http://localhost:3001/api/salones').then(res => setSalones(res.data));
      }} />
      {salones.length > 0 && (
        <Tabs selectedIndex={selectedSalon} onSelect={setSelectedSalon}>
          <TabList>
            {salones.map(salon => <Tab key={salon.id}>{salon.nombre}</Tab>)}
          </TabList>

          {salones.map(salon => (
            <TabPanel key={salon.id}>
              <CalendarView salon={salon} />
            </TabPanel>
          ))}
        </Tabs>
      )}

      {modalOpen && <EventModal closeModal={() => setModalOpen(false)} salones={salones} />}
    </div>
  );
}

export default App;